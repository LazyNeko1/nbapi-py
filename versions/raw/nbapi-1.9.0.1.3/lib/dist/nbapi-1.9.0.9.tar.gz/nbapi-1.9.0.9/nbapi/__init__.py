import asyncio, requests, json
from random import randint


# Note: Using this API you are going to be using a API that MAY (unlikely) But MAY send NSFW results.
# If that happens, DM my owner (LazyNeko#5644), or join the Neko Support Server from the website.

# Nothing much yet :3

#                   #-------------------------------------------------#
#                       To join: Copy the below link.  
#                       https://discord.gg/RauzUYK
#                   #--------------------------------------------------#

# You may edit this code to your needs. I dont mind ;3
# TODO: make requests smaller (DONE)
# TODO: make "hug"&"pat" animated&static endpoint! (STARTED STATIC, WILL START ON ANIMATED SOON!)
class api():
    def locked(key, api_type):

        url = "http://api.neko-bot.net/api/locked/{api_type}"
        headers = {"TagKey": f"{key}"}
        r = requests.get(url=url, headers=headers)
        if "403" not in r.status_code:
            return r.text
        if "403" in r.status_code:
            print(f"Invalid token ({key}) was supplied.")


class random():
    def anime(source=False, min="1", max=False, check=True):
        if source == False:

                return f"http://neko-bot.net/anime/anime{str(randint(int(min), int(str(requests.get('http://neko-bot.net/info/totalanime.txt').text))))}.png"

        if source == True:

            if max == False:
                total = requests.get('http://neko-bot.net/info/totalanime.txt').text
            if max is not False:
                total = max
            if check is True:
                while True:
                    num = str(randint(int(min), int(total)))
                    sources = json.loads(requests.get('http://neko-bot.net/info/anime.json').text)[f'{num}']
                    #print(sources)
                    if sources is "":
                        pass
                    if sources is not "":
                        break
                        # sources = json.loads(requests.get('http://neko-bot.net/info/anime.json').text)
            # animeNum = str(randint(int(min), int(total)))
            out = f"http://neko-bot.net/anime/{num}.png"
            # animeSource = sources[f"{animeNum}"]
            output = {"url": out, "source": sources, 'ID': str(num)}

            return dict(output)

    def neko(source=False, min='1', max=False, check=True):

        if source == False:
          #  if check is False:
                output = f"http://neko-bot.net/nekos/neko{str(randint(int(min), int(str(requests.get('http://neko-bot.net/info/totalnekos.txt').text))))}.png"
                return output

        if source == True:
            if max == False:
                total = requests.get('http://neko-bot.net/info/totalnekos.txt').text
            if max is not False:
                total = max
            if check is True:
                while True:
                    num = str(randint(int(min), int(total)))
                    sources = json.loads(requests.get('http://neko-bot.net/info/nekos.json').text)[f'{num}']
                    #print(sources)
                    if sources is "":
                        pass
                    if sources is not "":
                        break
                        # sources = json.loads(requests.get('http://neko-bot.net/info/anime.json').text)
            # animeNum = str(randint(int(min), int(total)))
            out = f"http://neko-bot.net/nekos/{num}.png"
            # animeSource = sources[f"{animeNum}"]
            output = {"url": out, "source": sources, 'ID': str(num)}


            return dict(output)

    class pat():
        def static():
            return f"http://neko-bot.net/pats/static/{str(randint(int(1), int(str(requests.get('http://neko-bot.net/info/totalpats.txt').text))))}.png"

        def animated():
            return f"http://neko-bot.net/pats/animated/{str(randint(int(1), int(str(requests.get('http://neko-bot.net/info/totalpats_a.txt').text))))}.png"

    class hug():
        def animated():
            return "This endpoint is not finished!"

        def static():
            return "This endpoint is not finished!"


class search():
    def neko(num, source=False):
        if source is True:
            sources = json.loads(requests.get('http://neko-bot.net/info/nekos.json').text)
            return {'url': 'http://neko-bot.net/nekos/' + str(num) + '.png', 'source': sources[str(num)],
                    'ID': str(num)}
        if source is not True:
            return 'http://neko-bot.net/nekos/' + str(num) + '.png'

    def anime(num, source=False):
        if source is not True:
            return 'http://neko-bot.net/anime/' + str(num) + '.png'
        if source is True:
            sources = json.loads(requests.get('http://neko-bot.net/info/anime.json').text)
            return {'url': 'http://neko-bot.net/anime/' + str(num) + '.png', 'source': sources[str(num)],
                    'ID': str(num)}
        # print(random.pat.animated() + random.neko() + random.anime())   #DEBUG 1


# print(search.neko(randint(1,10),True),search.anime(randint(1,63),True)) #DEBUG 2 (SEARCH WITH SOURCE)
#print(random.neko(source=True, check=True)) #CHECK FOR SOURCE-ONLY!


def version():
    return str(open("version.txt", "r").read())


