import nbapi
print(nbapi.random.anime())
